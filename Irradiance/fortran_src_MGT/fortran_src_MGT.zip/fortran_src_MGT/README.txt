Info regarding compilation of fortran code

1. Fortran compiler is already on mac. Command
$ which gfortran
gives answer
$ /usr/bin/gfortran

2. Need to change path for LUT at line 87:
pathSBDART='/Users/martigalitapias/Documents/SBDART/'

*** Put the LUTs wherever you want and specify the path. But I think you cannot exceed a number of characters (50?) or the pathSBDART will read incorrectly ***

3. Compile using code compile_get_ed0.sh
Compiles with no errors, just the following warning:
get_ed0.f:132.72:

     &(ed(k), k=1,nwl)                                                  
                                                                       1
Warning: Nonnegative width required in format string at (1)

4. The warning translates into runtime error when executing:

At line 132 of file get_ed0.f
Fortran runtime error: Nonnegative width required in format
(1A,1I, 92F)
      ^

5. After stackoverflow forum reading, I change line 130 from
        write(*,FMT='(1A,1I, 92F)')
to
        write(*,FMT='(1A, 1I3.0, 92F10.4)’)





